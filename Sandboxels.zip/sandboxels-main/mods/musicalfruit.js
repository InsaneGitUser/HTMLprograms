elements.beans.reactions = {
    head: {elem1:"methane", chance: .5},
    body: {elem1:"methane", chance: .5}
};
