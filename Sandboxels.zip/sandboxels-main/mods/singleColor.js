window.addEventListener('load', function() {for (var element in elements) {elements[element].singleColor = true;}});
