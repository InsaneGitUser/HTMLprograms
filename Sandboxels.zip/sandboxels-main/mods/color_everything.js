for (element in elements) {
    elements[element].customColor = true;
}