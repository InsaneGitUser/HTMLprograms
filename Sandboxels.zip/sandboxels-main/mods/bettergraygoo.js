elements.gray_goo.behavior = [ ["XX", "CH:gray_goo%25", "XX"], ["M2%5 AND CH:gray_goo0%25","XX","M2%5 AND CH:gray_goo%25"], ["XX","CH:gray_goo0%25 AND M1","XX"] ]
